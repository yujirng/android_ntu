import 'package:cloud_firestore/cloud_firestore.dart';

class SinhVien{
  String? id, hoten, lop, nam_sinh, quequan, anh;
  SinhVien({
    required this.id,
    required this.hoten,
    this.lop,
    this.nam_sinh,
    this.quequan,
    this.anh
});

  Map<String, dynamic> toJson() {
    return {
      'id': this.id,
      'hoten': this.hoten,
      'lop': this.lop,
      'nam_sinh': this.nam_sinh,
      'quequan': this.quequan,
      'anh': this.anh,
    };
  }

  factory SinhVien.fromJson(Map<String, dynamic> map) {
    return SinhVien(
      id: map['id'] as String,
      hoten: map['hoten'] as String,
      lop: map['lop'] as String,
      nam_sinh: map['nam_sinh'] as String,
      quequan: map['quequan'] as String,
      anh: map['anh'] as String,
    );
  }
}
class SinhVienSnapshot{
  SinhVien sinhVien;
  DocumentReference? documentReference;

  SinhVienSnapshot({
  required this.sinhVien,
  required this.documentReference,
});

  factory SinhVienSnapshot.fromSnapshot(DocumentSnapshot docSnapSV){
    return SinhVienSnapshot(
        sinhVien: SinhVien.fromJson(docSnapSV.data() as Map<String, dynamic>),
        documentReference: docSnapSV.reference);
  }

  //async xử lý bất đồng bộ -> dữ liệu trả về là Future
  Future<void> capNhat(SinhVien sv) async{
    return documentReference?.update(sv.toJson());
  }

  Future<void> xoa() async{
    return documentReference?.delete();
  }

  //Phương thức tĩnh thì truy xuất qua tên, không tĩnh thì truy xuất qua đối tượng.
  //static truy xuất dl qua firebase
  static Future<DocumentReference> themMoi(SinhVien sv) async{
    return FirebaseFirestore.instance.collection("SinhVien").add(sv.toJson());
  }

  //STREAM và FUTURE là hai dạng dl bất đồng bộ
  static Stream<List<SinhVienSnapshot>> dsSVTuFirebase(){
    Stream<QuerySnapshot> streamQS = FirebaseFirestore.instance.collection("SinhVien").snapshots();

    //Chuyển Stream<QS> --> Stream<List<DS>>
    Stream<List<DocumentSnapshot>> StreamListDocSnap =  streamQS.map(
            (querySn) => querySn.docs);
    //map1: Chuyển Stream<List> --> Stream<List khác kiểu>
    //map2: Chuyển List<DS> --> List<SVS>
    return StreamListDocSnap.map(
            (listDocSnap) => listDocSnap.map((docSnap) => SinhVienSnapshot.fromSnapshot(docSnap)).toList()
    );
  }

  static Stream<List<SinhVienSnapshot>> getALL(){
    Stream<QuerySnapshot> streamQS = FirebaseFirestore.instance.collection("SinhVien").snapshots();
    return streamQS.map((qs) => qs.docs.map((doc) => SinhVienSnapshot.fromSnapshot(doc)).toList());
  }

  static Future<List<SinhVienSnapshot>> dsSVTuFirebaseOneTime() async{
    QuerySnapshot qs = await FirebaseFirestore.instance.collection("SinhVien").get();
    return qs.docs.map((doc) => SinhVienSnapshot.fromSnapshot(doc)).toList();
  }
}


