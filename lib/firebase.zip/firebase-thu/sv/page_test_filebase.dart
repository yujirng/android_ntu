
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../widget_connect_filebase.dart';

/*class TestFirebaseApp extends StatelessWidget {
  const TestFirebaseApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MyFirebaseConnect();
  }
}

class TestFirebaseApp extends StatelessWidget {
  const TestFirebaseApp({Key? key}) : super(key: key);

 @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Firebase App"),
      ),
    );
  }
}
*/