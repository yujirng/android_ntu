import 'package:android/firebase/filebase_data.dart';
import 'package:android/firebase/widget_connect_filebase.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class FirebaseApp extends StatelessWidget {
  const FirebaseApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MyFirebaseConnect(
        builder: (context) => PageSVs(),
        errorMessage: "Lỗi",
        connectingMessage: "Xe độp ơi!"
    );
  }
}

class PageSVs extends StatelessWidget {
  const PageSVs({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Danh sách SV"),
      ),
      body: StreamBuilder<List<SinhVienSnapshot>>(
        stream: SinhVienSnapshot.getALL(),
        builder: (context, snapshot) {
          if(snapshot.hasError){
            print(snapshot.error);
            return Center(
              child: Text("Lỗi",
                style: TextStyle(color: Colors.red),),
            );
          }
          else
            if(!snapshot.hasData)
              return Center(
                child: CircularProgressIndicator(),
              );
            else{
              var list = snapshot.data!;
              return ListView.separated(
                  itemBuilder: (context, index) => ListTile(
                    leading: Text("${index +1}"),
                  ),
                  separatorBuilder: (context, index) => Divider(thickness: 1.5,),
                  itemCount: list.length
              );
            }
        },
      ),
    );
  }
}
